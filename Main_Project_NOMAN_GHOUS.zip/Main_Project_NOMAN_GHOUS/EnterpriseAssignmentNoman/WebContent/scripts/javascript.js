// this method will be used to call the insertData servlet using Ajax
function insertFilmData(address,id){
	// it will get all the input values and put them nicely in the variables  
    var filmName  = document.getElementById('filmName').value;
    var filmGenre   = document.getElementById('filmGenre').value;
    var filmCredits = document.getElementById('filmCredits').value;
    var filmYear=document.getElementById('filmYear').value;
    var filmGross= document.getElementById('filmGross').value;
    var filmCountry= document.getElementById('filmCountry').value;
    // this is the parameter that will be sent in the request
    var parameter = "?filmName="+filmName+"&filmGenre="+filmGenre+"&filmCredits="+filmCredits+"&filmYear="+filmYear+"&filmGross="+filmGross+"&filmCountry="+filmCountry;
    
    // it will create a new variable of XMLHTTPRequest
	 var xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
		  // once everything is fine it will call this method when it receives 200 status
	    if (this.readyState == 4 && this.status == 200) {
	    	// it will update the innerHTML of the given div with the responseText
	     document.getElementById(id).innerHTML = this.responseText;
	    }
	  };
	  // it will request the servlet using GET request and pass the parameter variable which we created earlier
	  xhttp.open("GET", address + parameter, true);
	  // and send the request
	  xhttp.send();
	
}

// this method will be used to call getAllFilms Servlet which will return all the films
function getAllFilmsData(address,id){
	// will assign the selectAllFilmsBox id to a variable  
    var selectBox = document.getElementById("selectAllFilmsBox");
    // will assign the value of selectBox to variable
    var selectedValue = selectBox.options[selectBox.selectedIndex].value;
    // will call the getOutputDiv which will return the div where we need to insert the responseText
    var outputDiv = getOutputDivId(selectedValue);
 // it will create a new variable of XMLHTTPRequest
	 var xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
		  // once everything is fine it will call this method when it receives 200 status
	    if (this.readyState == 4 && this.status == 200) {
	    	// it will update the innerHTML of the given div with the responseText
	    	if(selectedValue == "xml"){
	    		var text = convertXML(this.responseText); 
	    		document.getElementById(outputDiv).innerHTML = text;
	    	}
	    	else if(selectedValue == "json"){
	    		var text = convertJSON(this.responseText); 
	    		document.getElementById(outputDiv).innerHTML = text;
	    	}
	    	else{
	     document.getElementById(outputDiv).innerHTML = this.responseText;
	    	}
	    }
	  };
	// it will request the servlet using GET request and pass the parameter variable which we created earlier
	  xhttp.open("GET", address + "?format="+selectedValue, true);
	  // and send the request
	  xhttp.send();	
}
// this method will be used call getFilm Servlet which will return the searched film
function getSearchedFilmData(address,id){
	// will assign the selectSearchFilmBox id to a variable  
    var selectBox = document.getElementById("selectSearchFilmBox");
    // will assign the value of selectBox to variable
    var selectedValue = selectBox.options[selectBox.selectedIndex].value;
    // this will get the value of search field which we need to send in the request
    var search = document.getElementById('searchFilmName').value;
    // we will call the method to get the div id of where responseText needed to be placed
    var outputDiv = getOutputDivId(selectedValue);
	 var xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
	    if (this.readyState == 4 && this.status == 200) {
	     document.getElementById(outputDiv).innerHTML = this.responseText;
	    }
           if (this.readyState != 4 && this.status == 204) {
        	   // if the status code is 204 no content this will be executed
	     document.getElementById(id).innerHTML = this.responseText;
	    }
	  };
	// it will request the servlet using GET request and pass the parameter variable which we created earlier
	  xhttp.open("GET", address + "?format="+selectedValue+"&search="+search, true);
	  // and send the request
	  xhttp.send();
	
}

// this method will insert the 'Output1' in the string and return it 
function getOutputDivId(format){

    var outputDiv = format+"Output1";
    
    return outputDiv;
    
    
}
// this method will take xml data in paramtere and return it in nice human read able format
function convertXML(xml) {
	  var i;
	  var table = "<table border = 1>"
	  table +="<tr><th>Film_ID</th><th>Film_Name</th><th>Film_Year</th><th>Film_Credits</th><th>Film_Genre</th><th>Film_Gross</th><th>Film_Country</th></tr>";
	  var parser = new DOMParser();
	  var doc = parser.parseFromString(xml, 'application/xml');
	  var x = doc.getElementsByTagName('film');
	  for (i = 0; i <x.length; i++) { 		  
		  
		table += "<tr><td>" +
	    x[i].getElementsByTagName("filmId")[0].childNodes[0].nodeValue +
	    "</td><td>" +
	    x[i].getElementsByTagName("filmName")[0].childNodes[0].nodeValue +
	    "</td><td>" +
	    x[i].getElementsByTagName("filmYear")[0].childNodes[0].nodeValue +
	    "</td><td>" +
	    x[i].getElementsByTagName("filmCredits")[0].childNodes[0].nodeValue +
	    "</td><td>" +
	    x[i].getElementsByTagName("filmGenre")[0].childNodes[0].nodeValue +
	    "</td><td>" +
	    x[i].getElementsByTagName("filmGross")[0].childNodes[0].nodeValue +
	    "</td><td>" +
	    x[i].getElementsByTagName("filmCountry")[0].childNodes[0].nodeValue +
	    "</td></tr>";
	  }
	  table += "</table>"
	  return table;
	  
	}

// this method will take data in JSON format and return it in nice suitable human readable format
function convertJSON(json){	        
	        var jsonObj = JSON.parse(json);
	        var table = "<table border = 1>"
	      	  table +="<tr><th>Film_ID</th><th>Film_Name</th><th>Film_Year</th><th>Film_Credits</th><th>Film_Genre</th><th>Film_Gross</th><th>Film_Country</th></tr>";
	        for (x in jsonObj) {
	            table += "<tr><td>" + jsonObj[x].filmId + "</td>" +
	            "<td>" + jsonObj[x].filmName + "</td>" +
	            "<td>" + jsonObj[x].filmYear + "</td>" +
	            "<td>" + jsonObj[x].filmCredits + "</td>" +
	            "<td>" + jsonObj[x].filmGenre + "</td>" +
	            "<td>" + jsonObj[x].filmGross + "</td>" +
	            "<td>" + jsonObj[x].filmCountry + "</td></tr>";
	        }
	        table += "</table>";
	        return table;
}



